package com.bibhutisarap.dutymarker;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, grid, months; TextView title, credit; boolean dark=false;
    Calendar shown=Calendar.getInstance();
    Map<String,String> marks=new HashMap<>();
    String[] mon={"January","February","March","April","May","June","July","August","September","October","November","December"};
    String[] quotes={
        "Every ambulance worker brings hope closer to someone in need.",
        "Behind every siren is a team ready to make a difference.",
        "Ambulance workers turn urgency into care, one call at a time.",
        "Their courage moves with every mile.",
        "Fast hands, calm hearts, lifesaving work.",
        "Every response is a promise to help.",
        "When seconds matter, ambulance workers stand ready.",
        "Their service begins before the patient reaches the hospital.",
        "They carry skill, compassion and responsibility on every journey.",
        "A siren may be loud, but their dedication speaks louder.",
        "Every duty shift is another opportunity to save a life.",
        "Respect the people who answer the call when others need help most."
    };

    int navy=Color.rgb(18,58,104), blue=Color.rgb(22,119,210), red=Color.rgb(239,35,60), green=Color.rgb(24,169,104);

    public void onCreate(Bundle b){
        super.onCreate(b);
        build();
        showSplash();
    }

    void showSplash(){
        clear();
        LinearLayout splash=new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setPadding(28,40,28,40);
        splash.setBackgroundColor(dark?Color.rgb(12,27,45):Color.rgb(246,250,254));

        TextView icon=tv("📅\n108",48);
        icon.setGravity(Gravity.CENTER);
        splash.addView(icon,new LinearLayout.LayoutParams(-1,180));

        TextView name=tv("108 Duty Marker",30);
        name.setGravity(Gravity.CENTER);
        name.setTypeface(null,1);
        splash.addView(name);

        TextView by=tv("by BIBHUTI SARAP",17);
        by.setGravity(Gravity.CENTER);
        splash.addView(by);

        TextView line=tv("Mark Your Duty  •  Stay Organized",15);
        line.setGravity(Gravity.CENTER);
        splash.addView(line);

        root.addView(splash,new LinearLayout.LayoutParams(-1,0,1));
        new Handler().postDelayed(()->showCalendar(),1200);
    }
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(dark?Color.WHITE:Color.rgb(16,35,61)); t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(12,8,12,8); return t;}
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(14); return b;}

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        setContentView(root); showHome();
    }
    void clear(){root.removeAllViews();}
    void header(String name){
        LinearLayout h=new LinearLayout(this); h.setGravity(Gravity.CENTER_VERTICAL); h.setPadding(16,12,10,12);
        h.setBackgroundColor(dark?Color.rgb(12,27,45):navy);
        TextView x=tv("108 Duty Marker\nby BIBHUTI SARAP",20); x.setTextColor(Color.WHITE); h.addView(x,new LinearLayout.LayoutParams(0,-2,1));
        Button theme=btn(dark?"☀":"☾"); theme.setOnClickListener(v->{dark=!dark; showCalendar();}); h.addView(theme);
        root.addView(h);
    }
    void showHome(){
        clear(); header("home");
        LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setGravity(Gravity.CENTER); body.setPadding(24,30,24,24);
        TextView logo=tv("📅\n108",42); logo.setGravity(Gravity.CENTER); body.addView(logo,new LinearLayout.LayoutParams(-1,140));
        TextView w=tv("Welcome!",28); w.setGravity(Gravity.CENTER); body.addView(w);
        TextView s=tv("Select a month to mark your duty.",16); s.setGravity(Gravity.CENTER); body.addView(s);
        GridLayout mg=new GridLayout(this); mg.setColumnCount(3); mg.setPadding(0,20,0,10);
        for(int i=0;i<12;i++){Button b=btn(mon[i]); final int m=i; b.setOnClickListener(v->{shown.set(Calendar.MONTH,m); showCalendar();}); mg.addView(b,new ViewGroup.LayoutParams(0,65)); ((GridLayout.LayoutParams)b.getLayoutParams()).columnSpec=GridLayout.spec(m%3,1,1); ((GridLayout.LayoutParams)b.getLayoutParams()).rowSpec=GridLayout.spec(m/3);}
        body.addView(mg,new LinearLayout.LayoutParams(-1,390));
        Button today=btn("📅  Today"); today.setOnClickListener(v->{shown=Calendar.getInstance();showCalendar();}); body.addView(today);
        root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
    }
    void showAbout(){
        clear();
        header("about");
        LinearLayout body=new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER);
        body.setPadding(28,35,28,25);

        TextView logo=tv("📅\n108",42);
        logo.setGravity(Gravity.CENTER);
        body.addView(logo,new LinearLayout.LayoutParams(-1,150));

        TextView name=tv("108 Duty Marker",28);
        name.setGravity(Gravity.CENTER);
        name.setTypeface(null,1);
        body.addView(name);

        TextView credit=tv("Created & Designed by\nBIBHUTI SARAP",18);
        credit.setGravity(Gravity.CENTER);
        body.addView(credit);

        TextView info=tv("\nA simple duty-marking calendar for ambulance workers.\n\nThank you to every ambulance worker for your service.",15);
        info.setGravity(Gravity.CENTER);
        body.addView(info,new LinearLayout.LayoutParams(-1,0,1));

        Button contact=btn("✉  Contact");
        contact.setOnClickListener(v->{
            Intent i=new Intent(Intent.ACTION_SENDTO);
            i.setData(Uri.parse("mailto:bibhutisaraf59@gmail.com"));
            i.putExtra(Intent.EXTRA_SUBJECT,"108 Duty Marker - Contact");
            try{startActivity(i);}catch(Exception e){}
        });
        body.addView(contact,new LinearLayout.LayoutParams(-1,60));

        Button back=btn("← Back to Calendar");
        back.setOnClickListener(v->showCalendar());
        body.addView(back,new LinearLayout.LayoutParams(-1,60));

        root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
    }

    void showCalendar(){
        clear(); header(mon[shown.get(Calendar.MONTH)]);
        LinearLayout top=new LinearLayout(this); top.setPadding(10,5,10,0);
        Button prev=btn("‹"); prev.setOnClickListener(v->{shown.add(Calendar.MONTH,-1);showCalendar();});
        top.addView(prev); title=tv(mon[shown.get(Calendar.MONTH)],28); title.setTypeface(null,1); top.addView(title,new LinearLayout.LayoutParams(0,65,1));
        credit=tv("BIBHUTI SARAP",12); credit.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); top.addView(credit,new LinearLayout.LayoutParams(130,65)); Button next=btn("›"); next.setOnClickListener(v->{shown.add(Calendar.MONTH,1);showCalendar();}); top.addView(next); root.addView(top);
        TextView amb=tv("🚑",34); amb.setGravity(Gravity.RIGHT); amb.setPadding(0,0,22,0); root.addView(amb,new LinearLayout.LayoutParams(-1,48));
        grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL); grid.setPadding(10,0,10,0);
        LinearLayout days=new LinearLayout(this); String[] ds={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
        for(String d:ds){TextView z=tv(d,13); z.setGravity(Gravity.CENTER); z.setTypeface(null,1); days.addView(z,new LinearLayout.LayoutParams(0,42,1));} grid.addView(days);
        Calendar c=(Calendar)shown.clone(); c.set(Calendar.DAY_OF_MONTH,1); int lead=c.get(Calendar.DAY_OF_WEEK)-1; int max=c.getActualMaximum(Calendar.DAY_OF_MONTH);
        LinearLayout row=null;
        for(int cell=0;cell<lead+max;cell++){ if(cell%7==0){row=new LinearLayout(this);grid.addView(row,new LinearLayout.LayoutParams(-1,62));}
            final int day=cell-lead+1; TextView d=tv(day<1?"":(""+day),17); d.setGravity(Gravity.CENTER); if(day>0){ if(cell%7==0)d.setTextColor(red); if(cell%7==6)d.setTextColor(blue);
                String key=shown.get(Calendar.YEAR)+"-"+shown.get(Calendar.MONTH)+"-"+day; String mark=marks.get(key); if("D".equals(mark))d.setText("✓\n"+day); else if("O".equals(mark))d.setText("○\n"+day);
                d.setOnClickListener(v->{String old=marks.get(key);marks.put(key,old==null?"D":old.equals("D")?"O":""); if(marks.get(key).isEmpty())marks.remove(key); showCalendar();});
            } row.addView(d,new LinearLayout.LayoutParams(0,62,1));}
        root.addView(grid);
        TextView help=tv("Tap a date:  ✓ Duty   ○ Off   blank = Not Marked",13); help.setPadding(20,8,10,8); root.addView(help);
        TextView quote=tv("“"+quotes[shown.get(Calendar.MONTH)]+"”",14);
        quote.setGravity(Gravity.CENTER);
        quote.setPadding(18,8,18,8);
        root.addView(quote);
        TextView foot=tv("Service Saves Lives   ♥  108",15); foot.setGravity(Gravity.CENTER); foot.setPadding(0,10,0,12); root.addView(foot);
        LinearLayout actions=new LinearLayout(this);
        actions.setPadding(10,4,10,8);
        Button home=btn("Today"); home.setOnClickListener(v->{shown=Calendar.getInstance();showCalendar();});
        Button about=btn("About"); about.setOnClickListener(v->showAbout());
        actions.addView(home,new LinearLayout.LayoutParams(0,58,1));
        actions.addView(about,new LinearLayout.LayoutParams(0,58,1));
        root.addView(actions);
    }
}